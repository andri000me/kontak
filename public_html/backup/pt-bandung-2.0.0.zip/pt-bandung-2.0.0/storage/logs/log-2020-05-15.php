<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-15 02:27:39 --> Could not find the language line "Berikutnya"
ERROR - 2020-05-15 02:46:08 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\Ampps\www\sipa\application\models\Services_model.php 92
ERROR - 2020-05-15 02:46:10 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\Ampps\www\sipa\application\models\Services_model.php 92
ERROR - 2020-05-15 02:46:11 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\Ampps\www\sipa\application\models\Services_model.php 92
ERROR - 2020-05-15 02:46:11 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\Ampps\www\sipa\application\models\Services_model.php 92
ERROR - 2020-05-15 02:46:21 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\Ampps\www\sipa\application\models\Services_model.php 92
ERROR - 2020-05-15 02:46:22 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\Ampps\www\sipa\application\models\Services_model.php 92
