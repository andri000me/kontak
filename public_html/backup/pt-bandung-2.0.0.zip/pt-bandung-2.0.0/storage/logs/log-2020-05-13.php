<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 05:49:57 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:01 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:11 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:11 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:11 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:11 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:25:12 --> Query error: Table 'db_sipa.ea_settings' doesn't exist - Invalid query: SELECT *
FROM `ea_settings`
WHERE `name` = 'company_name'
ERROR - 2020-05-13 06:35:28 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\Ampps\www\sipa\system\database\drivers\mysqli\mysqli_driver.php 305
ERROR - 2020-05-13 06:36:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Ampps\www\sipa\application\views\appointments\book.php 100
ERROR - 2020-05-13 06:36:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Ampps\www\sipa\application\views\appointments\book.php 143
ERROR - 2020-05-13 06:36:07 --> Severity: error --> Exception: $name setting does not exist in database: require_captcha C:\Ampps\www\sipa\application\models\Settings_model.php 41
ERROR - 2020-05-13 06:36:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Ampps\www\sipa\application\views\appointments\book.php 100
ERROR - 2020-05-13 06:36:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Ampps\www\sipa\application\views\appointments\book.php 143
ERROR - 2020-05-13 06:36:29 --> Severity: error --> Exception: $name setting does not exist in database: require_captcha C:\Ampps\www\sipa\application\models\Settings_model.php 41
ERROR - 2020-05-13 06:37:23 --> Severity: error --> Exception: $name setting does not exist in database: company_name C:\Ampps\www\sipa\application\models\Settings_model.php 41
ERROR - 2020-05-13 06:37:27 --> Severity: error --> Exception: $name setting does not exist in database: company_name C:\Ampps\www\sipa\application\models\Settings_model.php 41
ERROR - 2020-05-13 06:37:29 --> Severity: error --> Exception: $name setting does not exist in database: company_name C:\Ampps\www\sipa\application\models\Settings_model.php 41
ERROR - 2020-05-13 06:37:41 --> Severity: error --> Exception: $name setting does not exist in database: company_name C:\Ampps\www\sipa\application\models\Settings_model.php 41
ERROR - 2020-05-13 06:38:00 --> Severity: error --> Exception: $name setting does not exist in database: company_name C:\Ampps\www\sipa\application\models\Settings_model.php 41
ERROR - 2020-05-13 06:38:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Ampps\www\sipa\application\views\appointments\book.php 100
ERROR - 2020-05-13 06:38:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Ampps\www\sipa\application\views\appointments\book.php 143
ERROR - 2020-05-13 06:38:05 --> Severity: error --> Exception: $name setting does not exist in database: require_captcha C:\Ampps\www\sipa\application\models\Settings_model.php 41
ERROR - 2020-05-13 06:38:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Ampps\www\sipa\application\views\appointments\book.php 100
ERROR - 2020-05-13 06:38:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Ampps\www\sipa\application\views\appointments\book.php 143
ERROR - 2020-05-13 06:38:16 --> Severity: error --> Exception: $name setting does not exist in database: require_captcha C:\Ampps\www\sipa\application\models\Settings_model.php 41
ERROR - 2020-05-13 06:41:32 --> Severity: error --> Exception: $name setting does not exist in database: company_name C:\Ampps\www\sipa\application\models\Settings_model.php 41
ERROR - 2020-05-13 06:41:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Ampps\www\sipa\application\views\appointments\book.php 100
ERROR - 2020-05-13 06:41:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Ampps\www\sipa\application\views\appointments\book.php 143
ERROR - 2020-05-13 06:41:36 --> Severity: error --> Exception: $name setting does not exist in database: require_captcha C:\Ampps\www\sipa\application\models\Settings_model.php 41
