<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-24 08:09:16 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-24 08:09:19 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-24 08:09:20 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-24 08:09:21 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-24 08:09:21 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-24 08:09:22 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-24 08:09:22 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-24 08:09:23 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-24 08:09:23 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
