<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-18 06:30:14 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\Ampps\www\sipa\application\views\appointments\book.php 341
ERROR - 2020-05-18 06:30:24 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\Ampps\www\sipa\application\views\appointments\book.php 341
