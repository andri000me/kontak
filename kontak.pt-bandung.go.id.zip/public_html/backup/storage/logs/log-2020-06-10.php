<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-10 08:46:06 --> EA\Engine\Types\Type: Invalid argument value provided (/sipa/index.php/appointments/index/83649919a7e90a55f2561d9ede5878aa)
ERROR - 2020-06-10 08:46:06 --> #0 C:\Ampps\www\sipa\application\controllers\Appointments.php(562): EA\Engine\Types\Type->__construct('/sipa/index.php...')
#1 C:\Ampps\www\sipa\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\Ampps\www\sipa\index.php(353): require_once('C:\\Ampps\\www\\si...')
#3 {main}
