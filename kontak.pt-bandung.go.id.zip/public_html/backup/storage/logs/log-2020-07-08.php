<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-08 08:22:55 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-07-08 08:22:58 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-07-08 16:01:44 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/kontak/application/views/backend/settings.php 530
ERROR - 2020-07-08 16:01:47 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/kontak/application/views/backend/settings.php 530
ERROR - 2020-07-08 16:01:48 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/kontak/application/views/backend/settings.php 530
ERROR - 2020-07-08 16:01:49 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/kontak/application/views/backend/settings.php 530
ERROR - 2020-07-08 16:02:00 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/kontak/application/views/backend/settings.php 530
ERROR - 2020-07-08 16:02:04 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/kontak/application/views/backend/settings.php 530
ERROR - 2020-07-08 16:02:24 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/kontak/application/views/backend/settings.php 530
ERROR - 2020-07-08 16:04:17 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/kontak/application/views/backend/settings.php 519
ERROR - 2020-07-08 16:04:21 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/kontak/application/views/backend/settings.php 519
ERROR - 2020-07-08 16:04:22 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/kontak/application/views/backend/settings.php 519
