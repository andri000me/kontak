<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-19 08:22:10 --> EA\Engine\Types\Type: Invalid argument value provided (/sipa/index.php/appointments/index/7f68d84c181b34cbf32b368a66407858)
ERROR - 2020-06-19 08:22:10 --> #0 C:\Ampps\www\sipa\application\controllers\Appointments.php(562): EA\Engine\Types\Type->__construct('/sipa/index.php...')
#1 C:\Ampps\www\sipa\system\core\CodeIgniter.php(532): Appointments->ajax_register_appointment()
#2 C:\Ampps\www\sipa\index.php(353): require_once('C:\\Ampps\\www\\si...')
#3 {main}
