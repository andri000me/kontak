<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-22 14:29:53 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-22 14:29:55 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-22 14:29:55 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-22 14:29:56 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-22 14:31:28 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-22 15:50:40 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-22 16:50:37 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-22 17:24:56 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-22 17:27:07 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
