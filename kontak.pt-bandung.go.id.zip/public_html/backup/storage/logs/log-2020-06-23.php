<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-23 08:52:36 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:52:43 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:52:44 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:54:43 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:55:44 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:55:46 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:55:46 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:55:47 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:55:47 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:55:48 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:57:10 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:57:11 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:57:11 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:57:12 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:57:13 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 08:58:19 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/main/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 16:03:44 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 16:03:56 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
ERROR - 2020-06-23 16:03:59 --> Severity: Compile Error --> Can't use method return value in write context /var/www/html/kontak/application/controllers/Appointments.php 355
